package serie1;

import org.junit.Test;

import static serie1.Arrays.findMinDifference;
import static org.junit.Assert.*;

public class FindMinDifferenceTest {
	
	@Test
	public void findMinDifference_OnBothEmptyArrays(){
		int[] v1 = new int[0];
		int[] v2 = new int[0];
		int diff = findMinDifference(v1, v2);
		assertEquals(-1, diff);	
	}
	
	@Test
	public void findMinDifference_OnAnArraysWithOneElementAndEmpty(){
		int[] v1 = new int[]{1};
		int[] v2 = new int[0];
		int diff = Arrays.findMinDifference(v1, v2);
		assertEquals(-1, diff);	
		diff = Arrays.findMinDifference(v2, v1);
		assertEquals(-1, diff);	
	}
	
	@Test
	public void findMinDifference_OnAnArraysWithOneElement(){
		int[] v1 = new int[]{-1};
		int[] v2 = new int[]{-1};
		int diff = Arrays.findMinDifference(v1, v2);
		assertEquals(0, diff);	
		diff = Arrays.findMinDifference(v2, v1);
		assertEquals(0, diff);	
	}
	
	@Test
	public void findMinDifference_OnAnArraysWithRandomElements(){
		int[] v1 = new int[]{-23, -10, 34, 68};
		int[] v2 = new int[]{-15, -12, 32, 33};
		int diff = Arrays.findMinDifference(v1, v2);
		assertEquals(1, diff);	
		diff = Arrays.findMinDifference(v2, v1);
		assertEquals(1, diff);	
	}
	
	@Test
	public void findMinDifference_OnAnArraysWithRandomNegativeElements(){
		int[] v1 = new int[]{-3,-27,-45,-68,-70,-81,-99};
		int[] v2 = new int[]{-9,-16,-25,-35,-75,-84};
		int diff = Arrays.findMinDifference(v1, v2);
		assertEquals(6, diff);	
		diff = Arrays.findMinDifference(v2, v1);
		assertEquals(6, diff);	
	}
	
	@Test
	public void findMinDifference_OnAnArraysWithRandomPositiveElements(){
		int[] v1 = new int[]{3,27,45,68,70,81,99};
		int[] v2 = new int[]{9,16,25,35,75,84};
		int diff = Arrays.findMinDifference(v1, v2);
		assertEquals(2, diff);	
		diff = Arrays.findMinDifference(v2, v1);
		assertEquals(2, diff);	
	}
	
}
